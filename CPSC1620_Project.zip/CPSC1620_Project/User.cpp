#include <string>
#include <iostream>
#include <vector>

#include "User.h"

using namespace std;

void User::loadUser(int userID, string userName, string userPassword, bool isAdmin)
{

}

void User::newUser(string userName, string userPassword, bool isAdmin)
{

}